"""配置。

yaml vs py ？？
- yaml, 通用的配置格式。 python, java, PHP, Go
- py, 在 python 项目中读取更方便。
"""

# 隐式等待的时间
IMPLICTLY_WAIT_TIMEOUT = 5

# host
HOST = 'http://120.78.128.25:8765'

