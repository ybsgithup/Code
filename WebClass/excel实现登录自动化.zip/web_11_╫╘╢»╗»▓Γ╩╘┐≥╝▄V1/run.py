"""收集和运行用例。"""

def run():
    pass