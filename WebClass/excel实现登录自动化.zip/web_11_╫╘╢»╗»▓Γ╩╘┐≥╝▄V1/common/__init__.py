"""通用的模块。
logger_handler
excel_handler
mysql

"""